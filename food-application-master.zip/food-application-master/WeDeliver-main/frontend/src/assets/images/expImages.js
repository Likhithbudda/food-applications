export const groceryBag = "http://img2.storyblok.com/filters:format(webp)/f/62776/860x642/4e0f98735d/grocery-bag.jpg";
export const burger = "http://img2.storyblok.com/filters:format(webp)/f/62776/860x642/eaf9ed1e62/burger.jpg";
