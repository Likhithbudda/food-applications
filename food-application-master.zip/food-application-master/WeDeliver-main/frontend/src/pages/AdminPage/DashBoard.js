import React from "react";

const dashBoard = () => {
  return <div>dashBoard</div>;
};

export default dashBoard;
