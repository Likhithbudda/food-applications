import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Provider } from "react-redux";
// import

const Admin = () => {
  return (
    <>This is admin panel</>
    // <>
    //   <BrowserRouter>
    //     <Route path="/admin/dashboard" element=<DashBoard /> />
    //     <Route path="/admin/restaurants" element=<CategoryPage />
    //   </BrowserRouter>
    // </>
  );
};

export default Admin;
